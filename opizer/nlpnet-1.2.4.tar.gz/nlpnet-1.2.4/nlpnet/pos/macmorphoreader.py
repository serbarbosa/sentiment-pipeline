
import warnings

# backwards compatibility
from nlpnet.pos.pos_reader import *

warnings.warn('Module macmorphoreader is deprecated. Use module pos_reader instead.')

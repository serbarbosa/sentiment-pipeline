
from nlpnet.pos.pos_reader import POSReader


from nlpnet.srl.train_srl import *
from nlpnet.srl.srl_reader import SRLReader

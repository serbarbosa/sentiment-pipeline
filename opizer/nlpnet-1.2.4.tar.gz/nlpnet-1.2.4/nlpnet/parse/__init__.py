from nlpnet.parse.parse_reader import DependencyReader
